﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Fisher
{
    public static class FisherYate
    {
        private static Random randomNumber = new Random();

        public static void doFisherShuffle(this object[] objects)
        {
            for (int i = objects.Length - 1; i > 0; i--) // can create a breakpoint to see changes
            {
                int j = getRandomNumberBetweenZeroAnd(i);
                objects.SwapValuesAtIndices(i, j);
            }
        }
        public static void doFisherShuffleAlternative(this object[] objects)
            {
                for (int i = 0; i < objects.Length-2; i++)
                {
                    int j = getRandomNumberBetweenZeroAnd((objects.Length - i)-1);
                    objects.SwapValuesAtIndices(i, i+j);
                }

            }
            private static int getRandomNumberBetweenZeroAnd(int i)
        {
            return randomNumber.Next(i + 1);
        }
    }
}
