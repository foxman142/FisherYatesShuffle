﻿using System;

namespace Fisher
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] letters = { "Apples", "Bananas", "Carrots", "Deli", "Elderberry" };

            //letters.doFisherShuffle();
            letters.doFisherShuffleAlternative();
           

            foreach(string letter in letters)
                Console.Write(letter + " ");

            Console.ReadKey();
        }
    }
}
