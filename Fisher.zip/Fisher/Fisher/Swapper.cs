﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Fisher
{
    public static class Swapper
    {
        public static void SwapValuesAtIndices(this object[] objects, int i, int j)
        {
            object temp = objects[i];
            objects[i] = objects[j];
            objects[j] = temp;
        }
    }
}
